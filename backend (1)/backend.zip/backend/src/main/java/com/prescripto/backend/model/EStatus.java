package com.prescripto.backend.model;

public enum EStatus {
    PENDING,
    APPROVED,
    REJECTED
}

