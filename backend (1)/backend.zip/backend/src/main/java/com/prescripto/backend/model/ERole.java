package com.prescripto.backend.model;

public enum ERole {
  ROLE_USER,
  ROLE_ADMIN
}
